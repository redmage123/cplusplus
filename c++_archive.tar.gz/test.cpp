#include <iostream>
#include <stdio.h>
#include <utility>

using namespace std;

int main() {

    pair<int,int> p;

    int a = 10;
    int b = 5;

    p.first = a;
    p.second = b;

    cout << "First = " << p.first << "Second is " << p.second << endl;
}
