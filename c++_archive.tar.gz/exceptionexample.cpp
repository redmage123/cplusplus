#include <iostream>

using namespace std;


int main(void) {
    int a = 10;
    int b = 0;
    double z;

    try {
        z = a/b;
        cout << z << endl;
    } catch(const exception& ex) {
        cerr << "Error: " << ex << endl;
        cerr << "Goodbye" << endl;
    }

    return(0);
}
