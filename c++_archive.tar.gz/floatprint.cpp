#include <iostream>
using namespace std;
int main() {
         
     float fValue = 10.1234;
     double dValue = 1000000.0;
     cout << fValue << endl;
     cout << dValue << endl;
     dValue = 0.00001;
     cout << dValue << endl;
    return (0);
}
