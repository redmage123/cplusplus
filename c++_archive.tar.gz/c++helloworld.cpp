#include <iostream>

using namespace std;

int main() {

    string mystring = "Hello World\n";

    cout << mystring;
    return(0);
}
