#include <iostream>
#include <vector>
#include <string>
 
using namespace std;
 
main() {
    vector<string> SS;
    SS.push_back("The number is 10");
    SS.push_back("The number is 20");
    SS.push_back("The number is 30");
    cout << "Loop by index:" << endl;

    int ii;
    for(ii=0; ii < SS.size(); ii++) {
        cout << SS[ii] << endl;
    }
}
