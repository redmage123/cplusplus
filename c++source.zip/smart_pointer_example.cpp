#include <iostream>
#include <memory>

using namespace std;

int main() {

    struct mystruct {
        char * data = "Foobar";
    }

    unique_ptr<struct mystruct> sPtr (new struct * mystruct);

     cout << sPtr->data << endl;
}




