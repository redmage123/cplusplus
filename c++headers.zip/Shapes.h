class Shape {
    protected:
        int width,height;
        float radius;
        string shapeType;
    public:
        Shape (int a=0, int b=0)
        {
            width=a;
            height=b;
        }
        Shape (float r) {
           radius = r;
        }
        virtual int area() = 0; 
};

class Rectangle: public Shape {
    public:
        Rectangle(int a, int b):Shape(a,b) {
        }
        int area() {
            cout <<"Rectangle class area :" << endl;
            return(width*height);
        }
};

class Triangle:public Shape {
    public: 
        Triangle(int a, int b): Shape(a,b){
        }
        int area() {
            cout <<"Triangle class area : " << endl;
            return(width*height/2);
        }
};

class Circle:public Shape {
    const float pi=3.1415926;
    public: 
    Circle(float r): Shape(r) {};
    float area() {
        return(pi*(radius * radius));
    }
    float circumference() {
        return(2 * pi * radius);
    }
};





