#include <iostream>

using namespace std;

int main() {
    string s = "Hello World";
    cout << s;
}
