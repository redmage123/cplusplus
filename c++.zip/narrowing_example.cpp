#include <iostream>

int main() {
//    int k = 10.6;
    int k {10.6}
    std::cout << "k = " << k << std::endl;

}
