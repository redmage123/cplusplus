#include <iostream>

// using namespace std;

int main() {

    std::string mystring = "Hello World";

    std::cout << mystring << "\n";
    std::cout <<" This " << "is" << "a" << "long string" << std::endl;
    return(0);
}
