#include <iostream>

using namespace std;

int main() {
    int i;
    cout << "Please enter an integer: ";
    cin >> i;
    cout << "The value you entered is " << i;
    cout << " and its double is " << i*2 << "\n";
    return(0);
}
