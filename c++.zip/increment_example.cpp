#include <iostream>

using namespace std;
int main() {

    int i = 10;
    int j = ++i;
    int k = i++;
    

    cout << i << endl;
    cout << j << endl;
    cout << k << endl;
    }
