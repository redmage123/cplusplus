#include <iostream>
#include <string>
#include <string.h>
#include <stdio.h>
#include <vector>

using namespace std;

class myString {

    char *  mystr;

    public:
        myString() {
        }
        myString(char * s) {
            mystr = new char [strlen(s)];
            strncpy(mystr,s,strlen(s));
        }
        ~myString() {
            delete [] mystr;
        }

        myString(myString&& ms) {
            printf("Calling move constructor\n");
            mystr = ms.mystr;
            ms.mystr = NULL;
        }
        
        myString(const myString &ms) {
            cerr << "Calling copy constructor" << endl;
            mystr = new char [strlen(ms.mystr)];
            strncpy( mystr, ms.mystr,strlen(ms.mystr));
        }

        myString& operator=(myString&& ms) {
           printf("In move assignment\n");
            if (this != &ms) {
                swap(mystr,ms.mystr);
             }
             return(*this);
        }

        myString & operator=(const myString &ms) {
          printf("In copy assignment\n");
            if (this == &ms) {
                return *this;
            }
            mystr = new char [strlen(ms.mystr)];
            strncpy( mystr, ms.mystr,strlen(ms.mystr));
            return *this;
        }


        void changeString(char * s) {
            strcpy(mystr,s);
        }
        char * getString() {
          return mystr;
        }
};

int main(void) {

     vector<myString> v;
     myString A("Hello World");
     myString B("Goodbye World");
     printf("Doing first push back\n");
     v.push_back(static_cast<myString &&> (A));
     printf("Doing second push back\n");
     v.push_back(static_cast<myString &&> (B));
     printf("End of program\n");
}




  
