#include <iostream>

using namespace std;

int main() {

    struct test {
        int foo;
        char bar;
    };

    struct test * t = new struct test[10];

    t[0].foo = 1;
    t[0].bar = 'a';
}



