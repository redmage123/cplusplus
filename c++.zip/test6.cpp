#include <stdio.h>
#include <vector>
using namespace std;

int main() {

  vector <int> v;


  int a;
  v.push_back(a=10);
}
