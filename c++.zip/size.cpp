#include <iostream>
int main() {
    int total;

    std::cout << sizeof(total) << std::endl;
}
