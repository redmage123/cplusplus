#include "arithmeticWrapper.h"


arithmeticWrapper::add(int x, int y) { return(x+y); }
arithmeticWrapper::sub() { }
arithmeticWrapper::mul() { }
arithmeticWrapper::div() { }
