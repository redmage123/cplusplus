#include <iostream>
#include <math.h>

using namespace std;

const double pi = 3.1415926;
int main(void) {

    int a = 5;
    cout << pow(a,2.0)  << endl;
}
